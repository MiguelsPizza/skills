---
example:
  primary: no-magic-values
  format: code
  implements:
    - no-magic-values
    - jsdoc-with-first-party-sources
    - otel-conventions-from-day-one
---
# No Magic Values

**Rule:** Give every literal that controls behavior a named constant and provenance. Inline literals are allowed for obvious identities.

See also: [Comments and JSDoc Must Carry Information](./jsdoc-with-first-party-sources.md) and [OTEL Conventions from Day One](./otel-conventions-from-day-one.md).

## Why agents get this wrong

Values buried in control flow are easy to copy without knowing whether they were deliberate, arbitrary, or obsolete.

## What to do instead

Group behavioral constants by domain and document why each value exists. Use `as const satisfies` for constant objects to preserve literal types and check completeness.

```typescript
/** 3 balances reliability with GitHub's 10 second webhook timeout. */
export const MAX_RETRIES = 3;

/** Base retry delay in milliseconds. Exponential backoff multiplies from here. */
export const RETRY_BASE_DELAY_MS = 1000;

export const GITHUB_EVENTS = {
  PULL_REQUEST: 'pull_request',
  INSTALLATION: 'installation',
} as const satisfies Record<string, string>;

if (attempts > MAX_RETRIES) throw error;
await sleep(RETRY_BASE_DELAY_MS * 2 ** attempts);
headers.set('X-GitHub-Event', GITHUB_EVENTS.PULL_REQUEST);
```

Mark arbitrary values as `Arbitrary` in JSDoc and explain their rationale so contributors know they can be tuned.

## Example

Webhook constants

```typescript
/**
 * GitHub sends the event type in the `X-GitHub-Event` header.
 *
 * @see https://docs.github.com/en/webhooks/webhook-events-and-payloads
 */
export const GITHUB_EVENT_HEADER = 'X-GitHub-Event';

/**
 * Pull request webhook event name.
 *
 * @see https://docs.github.com/en/webhooks/webhook-events-and-payloads#pull_request
 */
export const GITHUB_EVENT_PULL_REQUEST = 'pull_request';
```

Retry policy owner

```typescript
/**
 * 3 balances transient retry recovery against the webhook latency budget.
 *
 * @see ./.sources/github-webhook-retry-budget.md
 */
export const MAX_GITHUB_API_ATTEMPTS = 3;
```

Feature usage

```typescript
import {
  GITHUB_EVENT_HEADER,
  GITHUB_EVENT_PULL_REQUEST,
} from '@repo/github-client/github-webhook-event';
import { MAX_GITHUB_API_ATTEMPTS } from '@repo/github-client/github-api-retry-policy';
import { LOG_EVENTS } from '@repo/contracts/observability/log-events';
import { OTEL_ATTRS } from '@repo/contracts/observability/otel-attrs';

if (attempts > MAX_GITHUB_API_ATTEMPTS) throw error;
headers.set(GITHUB_EVENT_HEADER, GITHUB_EVENT_PULL_REQUEST);
logger.info(LOG_EVENTS.GITHUB_WEBHOOK_RECEIVED, {
  [OTEL_ATTRS.HTTP_ROUTE]: '/webhooks/github',
});
```

Example implements: [No Magic Values](./no-magic-values.md), [Comments and JSDoc Must Carry Information](./jsdoc-with-first-party-sources.md), [OTEL Conventions from Day One](./otel-conventions-from-day-one.md).
