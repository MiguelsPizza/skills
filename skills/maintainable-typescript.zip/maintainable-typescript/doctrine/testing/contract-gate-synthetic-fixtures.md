---
example:
  primary: contract-gate-synthetic-fixtures
  format: code
  implements:
    - contract-gate-synthetic-fixtures
    - ssot-or-die
    - boundaries-validate-internals-trust
---
# Contract-Gate Synthetic Fixtures

**Rule:** Any payload invented by a durable test should be parsed by a runtime schema before the test returns it or sends it.

See also: [SSOT or Die](../abstractions/ssot-or-die.md) and [Boundaries Validate, Internals Trust](../boundaries/boundaries-validate-internals-trust.md).

## Why agents get this wrong

Agents hand-write JSON fixtures inline because it is fast. That creates silent drift:

- renamed fields
- missing required fields
- wrong nested object shapes
- stale assumptions about external APIs

The tests still compile, but they stop modeling the real contract.

## What to do instead

Before a test injects synthetic data:

1. choose the canonical runtime schema
2. build the payload through that schema
3. only then serialize or return it

Prefer:

- app-owned schemas from the real contract package
- explicit external-boundary schemas when the payload belongs to a third-party provider

Do not normalize this as "validation everywhere." The point is to validate at the synthetic edge where the test invents data.

## Example

Inbound webhook example:

```typescript
const webhookPayload = gitHubPullRequestWebhookPayloadSchema.parse({
  action: "opened",
  repository: { id: 101, full_name: "acme/app" },
  installation: { id: 1 },
  pull_request: { number: 42, html_url: "https://github.com/acme/app/pull/42" },
});

const response = await app.request("/api/github/webhooks", {
  method: "POST",
  headers: {
    "X-GitHub-Event": "pull_request",
    "X-GitHub-Delivery": "delivery_123",
  },
  body: JSON.stringify(webhookPayload),
});

expect(response.status).toBe(202);
```

App-owned route example:

```typescript
const response = await app.request("/api/review-runs", {
  method: "POST",
  body: JSON.stringify(createReviewRunInputSchema.parse({
    installationId: "inst_123",
    repositoryName: "acme/app",
    pullRequestNumber: 42,
  })),
});

expect(response.status).toBe(202);
```

Example implements: [Contract-Gate Synthetic Fixtures](./contract-gate-synthetic-fixtures.md), [SSOT or Die](../abstractions/ssot-or-die.md), [Boundaries Validate, Internals Trust](../boundaries/boundaries-validate-internals-trust.md).
